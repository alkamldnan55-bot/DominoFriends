package com.domino.friends

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Green = Color(0xFF176B4D)
private val Cream = Color(0xFFF6F7F2)
private data class Team(val id: Long, val name: String, val p1: String, val p2: String)
private data class Round(val a: Int, val b: Int)
private data class Match(val id: Long, val teamA: Long, val teamB: Long, val nameA: String, val nameB: String, val rounds: List<Round>, val scoreA: Int, val scoreB: Int, val winner: String, val date: String, val mode: String)
private data class LiveMatch(val a: Long, val b: Long, val timed: Boolean, val seconds: Int)
private data class TeamStats(val team: Team, val wins: Int, val losses: Int, val points: Int, val played: Int)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { DominoApp() } }
}

@Composable private fun DominoApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { context.getSharedPreferences("domino_friends", 0) }
    var teams by remember { mutableStateOf(loadTeams(prefs.getString("teams", "[]") ?: "[]")) }
    var matches by remember { mutableStateOf(loadMatches(prefs.getString("matches", "[]") ?: "[]")) }
    var tab by remember { mutableIntStateOf(0) }
    var showAddTeam by remember { mutableStateOf(false) }
    var showNewMatch by remember { mutableStateOf(false) }
    var activeMatch by remember { mutableStateOf<LiveMatch?>(null) }
    fun save() { prefs.edit().putString("teams", teamsJson(teams).toString()).putString("matches", matchesJson(matches).toString()).apply() }
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, background = Cream, surface = Color.White)) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides LayoutDirection.Rtl) {
            Scaffold(containerColor = Cream, bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.EmojiEvents, null) }, label = { Text("الترتيب") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Groups, null) }, label = { Text("الفرق") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("السجل") })
                }
            }, floatingActionButton = {
                if (tab == 1) FloatingActionButton(onClick = { showAddTeam = true }, containerColor = Green, contentColor = Color.White) { Icon(Icons.Default.Add, "إضافة فريق") }
                if (tab == 0) FloatingActionButton(onClick = { if (teams.size >= 2) showNewMatch = true }, containerColor = Green, contentColor = Color.White) { Icon(Icons.Default.SportsEsports, "مباراة جديدة") }
            }) { padding ->
                Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                    Spacer(Modifier.height(18.dp)); Text("دومينو الأصدقاء", fontSize = 27.sp, fontWeight = FontWeight.Bold, color = Green)
                    Text("سجلّ المباريات والترتيب اليومي", color = Color.Gray, fontSize = 13.sp); Spacer(Modifier.height(18.dp))
                    when (tab) { 0 -> RankingScreen(teams, matches) { showNewMatch = true }; 1 -> TeamsScreen(teams) { id -> teams = teams.filterNot { it.id == id }; save() }; else -> HistoryScreen(matches) }
                }
            }
        }
    }
    if (showAddTeam) AddTeamDialog({ showAddTeam = false }) { n, a, b -> teams = teams + Team(System.currentTimeMillis(), n, a, b); save(); showAddTeam = false }
    if (showNewMatch) NewMatchDialog(teams, { showNewMatch = false }) { a, b, timed, minutes -> activeMatch = LiveMatch(a, b, timed, minutes * 60); showNewMatch = false }
    activeMatch?.let { live -> MatchDialog(live, teams, { activeMatch = null }) { rounds, sa, sb, winner, mode ->
        val ta = teams.first { it.id == live.a }; val tb = teams.first { it.id == live.b }
        matches = matches + Match(System.currentTimeMillis(), live.a, live.b, ta.name, tb.name, rounds, sa, sb, winner, SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date()), mode)
        save(); activeMatch = null
    } }
}

@Composable private fun RankingScreen(teams: List<Team>, matches: List<Match>, onNew: () -> Unit) {
    val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()); val todayMatches = matches.filter { it.date.startsWith(today) }
    val stats = teams.map { team ->
        val played = todayMatches.filter { it.teamA == team.id || it.teamB == team.id }
        val wins = played.count { it.winner == team.name }
        val losses = played.count { it.winner != team.name && it.winner != "تعادل" }
        val points = played.sumOf { if (it.teamA == team.id) it.scoreA else it.scoreB }
        TeamStats(team, wins, losses, points, played.size)
    }.sortedWith(compareByDescending<TeamStats> { it.wins }.thenByDescending { it.points })
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) { Text("ترتيب اليوم", fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("${todayMatches.size} مباراة", color = Color.Gray, fontSize = 13.sp) }
    Spacer(Modifier.height(10.dp))
    if (stats.isEmpty()) EmptyState("لم تضف فرقاً بعد", "أضف الفرق من تبويب الفرق للبدء") else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
        items(stats) { item -> val team = item.team; Card(shape = RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(team.name, fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("${team.p1} و ${team.p2}", color = Color.Gray, fontSize = 11.sp) }; Stat("${item.played}", "لعب"); Spacer(Modifier.width(8.dp)); Stat("${item.wins}", "فوز", Green); Spacer(Modifier.width(8.dp)); Stat("${item.losses}", "خسارة", Color(0xFFB3261E)); Spacer(Modifier.width(8.dp)); Stat("${item.points}", "نقطة") } } }
        item { Button(onClick = onNew, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("بدء مباراة جديدة") } }
    }
}
@Composable private fun Stat(value: String, label: String, color: Color = Color.DarkGray) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontWeight = FontWeight.Bold, fontSize = 19.sp, color = color); Text(label, fontSize = 10.sp, color = Color.Gray) } }
@Composable private fun TeamsScreen(teams: List<Team>, onDelete: (Long) -> Unit) {
    Text("الفرق المسجلة (${teams.size})", fontWeight = FontWeight.Bold, fontSize = 20.sp); Spacer(Modifier.height(10.dp))
    if (teams.isEmpty()) EmptyState("لا توجد فرق", "اضغط + لإضافة فريق ولاعبيه") else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 90.dp)) { items(teams) { team -> Card(shape = RoundedCornerShape(15.dp)) { Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(team.name, fontWeight = FontWeight.Bold, fontSize = 17.sp); Text("${team.p1}  •  ${team.p2}", color = Color.Gray, fontSize = 13.sp) }; TextButton(onClick = { onDelete(team.id) }) { Text("حذف", color = Color(0xFFB3261E)) } } } } }
}
@Composable private fun HistoryScreen(matches: List<Match>) {
    Text("سجل المباريات (${matches.size})", fontWeight = FontWeight.Bold, fontSize = 20.sp); Spacer(Modifier.height(10.dp))
    if (matches.isEmpty()) EmptyState("لا توجد مباريات مسجلة", "ستظهر نتائج مبارياتكم هنا") else LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) { items(matches.sortedByDescending { it.id }) { m -> Card(shape = RoundedCornerShape(15.dp)) { Column(Modifier.fillMaxWidth().padding(14.dp)) { Text("${m.nameA}  ${m.scoreA} - ${m.scoreB}  ${m.nameB}", fontWeight = FontWeight.Bold); Text("الفائز: ${m.winner}  •  ${m.mode}", color = Green, fontSize = 13.sp); Text(m.date, color = Color.Gray, fontSize = 11.sp); Text("الجولات: ${m.rounds.joinToString("، ") { "${it.a}-${it.b}" }}", color = Color.Gray, fontSize = 12.sp) } } } }
}
@Composable private fun EmptyState(title: String, subtitle: String) { Box(Modifier.fillMaxWidth().padding(top = 60.dp), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(title, fontWeight = FontWeight.Bold, fontSize = 18.sp); Spacer(Modifier.height(6.dp)); Text(subtitle, color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center) } } }

@Composable private fun AddTeamDialog(onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }; var p1 by remember { mutableStateOf("") }; var p2 by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("إضافة فريق") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(name, { name = it }, label = { Text("اسم الفريق") }, singleLine = true); OutlinedTextField(p1, { p1 = it }, label = { Text("اسم اللاعب الأول") }, singleLine = true); OutlinedTextField(p2, { p2 = it }, label = { Text("اسم اللاعب الثاني") }, singleLine = true) } }, confirmButton = { TextButton(enabled = name.isNotBlank() && p1.isNotBlank() && p2.isNotBlank(), onClick = { onSave(name.trim(), p1.trim(), p2.trim()) }) { Text("حفظ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}
@Composable private fun NewMatchDialog(teams: List<Team>, onDismiss: () -> Unit, onStart: (Long, Long, Boolean, Int) -> Unit) {
    var a by remember { mutableStateOf(teams.firstOrNull()?.id ?: 0L) }; var b by remember { mutableStateOf(teams.getOrNull(1)?.id ?: 0L) }; var timed by remember { mutableStateOf(false) }; var minutes by remember { mutableStateOf("15") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("مباراة جديدة") }, text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("الفريق الأول"); TeamDropdown(teams, a) { a = it }; Text("الفريق الثاني"); TeamDropdown(teams, b) { b = it }; Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(timed, { timed = it }); Text("مباراة بالوقت") }; if (timed) OutlinedTextField(minutes, { minutes = it.filter(Char::isDigit) }, label = { Text("مدة المباراة بالدقائق") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); Text(if (timed) "الفائز صاحب النقاط الأعلى عند إنهاء الوقت" else "يفوز أول فريق يصل إلى 11 نقطة", color = Color.Gray, fontSize = 12.sp) } }, confirmButton = { TextButton(enabled = a != b && a != 0L && b != 0L && (!timed || (minutes.toIntOrNull() ?: 0) > 0), onClick = { onStart(a, b, timed, if (timed) minutes.toInt() else 0) }) { Text("ابدأ") } }, dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } })
}
@Composable private fun TeamDropdown(teams: List<Team>, selected: Long, onSelect: (Long) -> Unit) { var expanded by remember { mutableStateOf(false) }; val team = teams.firstOrNull { it.id == selected }; Box { OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) { Text(team?.name ?: "اختر فريقاً") }; DropdownMenu(expanded, { expanded = false }) { teams.forEach { DropdownMenuItem(text = { Text(it.name) }, onClick = { onSelect(it.id); expanded = false }) } } } }

@Composable private fun MatchDialog(live: LiveMatch, teams: List<Team>, onDismiss: () -> Unit, onFinish: (List<Round>, Int, Int, String, String) -> Unit) {
    val ta = teams.first { it.id == live.a }; val tb = teams.first { it.id == live.b }; val rounds = remember { mutableStateListOf<Round>() }
    var inputA by remember { mutableStateOf("") }; var inputB by remember { mutableStateOf("") }; var seconds by remember { mutableIntStateOf(live.seconds) }; var running by remember { mutableStateOf(live.timed) }; var confirmEnd by remember { mutableStateOf(false) }
    val scoreA = rounds.sumOf { it.a }; val scoreB = rounds.sumOf { it.b }
    LaunchedEffect(running, live.timed) { while (running && seconds > 0) { delay(1000); seconds-- }; if (live.timed && seconds == 0) confirmEnd = true }
    fun finish(mode: String) { val winner = when { scoreA > scoreB -> ta.name; scoreB > scoreA -> tb.name; else -> "تعادل" }; onFinish(rounds.toList(), scoreA, scoreB, winner, mode) }
    LaunchedEffect(scoreA, scoreB, live.timed) { if (!live.timed && (scoreA >= 11 || scoreB >= 11)) finish("حتى 11 نقطة") }
    AlertDialog(onDismissRequest = {}, title = { Text("${ta.name} × ${tb.name}") }, text = { Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
        if (live.timed) Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) { Text("الوقت المتبقي", color = Color.Gray); Text(String.format(Locale.getDefault(), "%02d:%02d", seconds / 60, seconds % 60), fontWeight = FontWeight.Bold, fontSize = 20.sp); TextButton(onClick = { running = !running }) { Text(if (running) "إيقاف" else "استئناف") } }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { ScoreBox(ta.name, scoreA); ScoreBox(tb.name, scoreB) }; Text("إضافة نقاط الجولة", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(inputA, { inputA = it.filter(Char::isDigit) }, label = { Text(ta.name) }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true); OutlinedTextField(inputB, { inputB = it.filter(Char::isDigit) }, label = { Text(tb.name) }, modifier = Modifier.weight(1f), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true) }
        Button(onClick = { rounds.add(Round(inputA.toIntOrNull() ?: 0, inputB.toIntOrNull() ?: 0)); inputA = ""; inputB = "" }, modifier = Modifier.fillMaxWidth(), enabled = inputA.isNotBlank() || inputB.isNotBlank()) { Text("تسجيل الجولة") }
        if (rounds.isNotEmpty()) Text("الجولات: ${rounds.mapIndexed { i, r -> "${i + 1}) ${r.a}-${r.b}" }.joinToString("   ")}", fontSize = 12.sp, color = Color.Gray)
        if (!live.timed) Text("الفوز تلقائي عند بلوغ 11 نقطة", color = Green, fontSize = 12.sp)
    } }, confirmButton = { Column(horizontalAlignment = Alignment.End) { if (!live.timed && (scoreA >= 11 || scoreB >= 11)) TextButton(onClick = { finish("حتى 11 نقطة") }) { Text("إنهاء وإعلان الفائز") }; if (live.timed) TextButton(onClick = { running = false; confirmEnd = true }) { Text("إنهاء المباراة") }; TextButton(onClick = onDismiss) { Text("إلغاء المباراة") } } })
    if (confirmEnd) AlertDialog(onDismissRequest = { confirmEnd = false }, title = { Text("إنهاء المباراة؟") }, text = { Text(if (scoreA == scoreB) "النتيجة متعادلة ($scoreA - $scoreB)." else "${if (scoreA > scoreB) ta.name else tb.name} متقدم بالنتيجة $scoreA - $scoreB.") }, confirmButton = { TextButton(onClick = { finish("بالوقت") }) { Text("تأكيد النتيجة") } }, dismissButton = { TextButton(onClick = { confirmEnd = false; running = true }) { Text("متابعة") } })
}
@Composable private fun ScoreBox(name: String, score: Int) { Card(colors = CardDefaults.cardColors(containerColor = Cream)) { Column(Modifier.width(105.dp).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text(name, fontSize = 13.sp, fontWeight = FontWeight.Bold); Text("$score", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Green) } } }

private fun teamsJson(teams: List<Team>) = JSONArray().apply { teams.forEach { put(JSONObject().put("id", it.id).put("name", it.name).put("p1", it.p1).put("p2", it.p2)) } }
private fun loadTeams(raw: String): List<Team> = runCatching { val a = JSONArray(raw); (0 until a.length()).map { val o = a.getJSONObject(it); Team(o.getLong("id"), o.getString("name"), o.getString("p1"), o.getString("p2")) } }.getOrDefault(emptyList())
private fun matchesJson(matches: List<Match>) = JSONArray().apply { matches.forEach { m -> put(JSONObject().put("id", m.id).put("ta", m.teamA).put("tb", m.teamB).put("na", m.nameA).put("nb", m.nameB).put("sa", m.scoreA).put("sb", m.scoreB).put("winner", m.winner).put("date", m.date).put("mode", m.mode).put("rounds", JSONArray().apply { m.rounds.forEach { put(JSONObject().put("a", it.a).put("b", it.b)) } })) } }
private fun loadMatches(raw: String): List<Match> = runCatching { val a = JSONArray(raw); (0 until a.length()).map { val o = a.getJSONObject(it); val rr = o.getJSONArray("rounds"); Match(o.getLong("id"), o.getLong("ta"), o.getLong("tb"), o.getString("na"), o.getString("nb"), (0 until rr.length()).map { i -> Round(rr.getJSONObject(i).getInt("a"), rr.getJSONObject(i).getInt("b")) }, o.getInt("sa"), o.getInt("sb"), o.getString("winner"), o.getString("date"), o.getString("mode")) } }.getOrDefault(emptyList())
